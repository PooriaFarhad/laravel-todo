@extends('layouts.app')

@section('content')
    <div class="container">
        <a class="btn btn-primary" href="{{ route('todos.create') }}">Create Todo</a>
        <a class="btn btn-primary" href="{{ route('todos.index', ['completed' => 1]) }}">
            Show Completed Todos
        </a>
        <a class="btn btn-primary" href="{{ route('todos.index') }}">
            Show All Todos
        </a>
        @if(session('msg'))
            <div class="alert alert-info">
                {{ session('msg') }}
            </div>
        @endif
        @foreach($todos as $todo)
            <h2>{{ $todo->title }}</h2>
            <form action="{{ route('todos.destroy', [$todo->id]) }}" method="POST">
                @csrf
                @method('DELETE')
                <button type="submit">
                    Delete
                </button>
            </form>
            <form action="{{ route('todos.toggle', [$todo->id]) }}" method="POST">
                @csrf
                @method('PATCH')
                <button type="submit">
                    @if($todo->is_completed)
                        UNDO
                    @else
                        DONE
                    @endif
                </button>
            </form>
        @endforeach
        {{ $todos->links() }}
    </div>
@endsection