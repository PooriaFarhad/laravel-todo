<?php

namespace App\Http\Controllers;

use App\Http\Requests\TodoRequest;
use App\Todo;
use Illuminate\Http\Request;

class TodoController extends Controller
{
    public function index(Request $request)
    {
//        $todos = Todo::all();
//        \DB::enableQueryLog();
        $todos = Todo::orderBy('id', 'desc');
        if ($request->get('completed')) {
            $todos->where('is_completed', 1);
        }
        $todos = $todos->paginate(10);
//        dd(\DB::getQueryLog());

        return view('todos.index', ['todos' => $todos]);
    }

    public function create()
    {
        return view('todos.create');
    }

    public function store(TodoRequest $request)
    {
//        $todo = $request->only('title') + ['user_id' => \Auth::id()];
//        Todo::create($todo);
        $todo = new Todo;
        $todo->title = $request->get('title');
        $todo->user_id = \Auth::id();
        $todo->save();

        return redirect()->route('todos.index');
    }

    public function destroy($id)
    {
        $todo = Todo::findOrFail($id);
//        if (\Gate::allows('update-access', $todo)) {
//            $todo->delete();
//        } else {
//            abort(403);
//        }
//        dd(\Auth::user()->can('update', $todo));
        $todo->authorize('update', $todo);
        return back();
    }

    public function toggle($id)
    {
        $todo = Todo::findOrFail($id);
        $todo->is_completed = ! $todo->is_completed;
        $todo->save();

        return back()->with('msg', __('msg.todo-created'));
    }
}
